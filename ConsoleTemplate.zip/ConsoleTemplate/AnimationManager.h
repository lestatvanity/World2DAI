﻿#pragma once
#include "AnimationComponent.h"
#include <unordered_map>
#include <string>
#include <memory>

class AnimationManager {
public:
    void add(const std::string& name, const Animation& anim);
    const Animation& get(const std::string& name) const;

    void loadFromFile(const std::string& path);
    void saveToFile(const std::string& path);

    void updateAll(float dt); // 🔧 questo richiede il membro components
    void registerComponent(const std::string& id, std::shared_ptr<AnimationComponent> comp);

private:
    std::unordered_map<std::string, Animation> animations;
    std::unordered_map<std::string, std::shared_ptr<AnimationComponent>> components; // 🔥 aggiunto
};
