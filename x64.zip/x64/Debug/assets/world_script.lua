-- Lua script generato automaticamente
tiles[52] = { name = '', type = '', walkable = true, category = '', genre = '' }
tiles[-1] = { name = '', type = '', walkable = true, category = '', genre = '' }
tiles[75] = { name = '', type = '', walkable = true, category = '', genre = '' }
tiles[51] = { name = 'Acqua', type = 'Acqua', walkable = false, category = 'vcvv', genre = 'vcvccvcv' }
