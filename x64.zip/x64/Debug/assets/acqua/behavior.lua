TileBehavior = {
  onEnter = function(player, tileID)
    if tileID == 3 then
      player.speed = player.speed * 0.8
    end
  end
}
