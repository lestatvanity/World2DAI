return {
    onUpdate = function(npc)
      npc:moveBy(1, 0)
    end
  }
  