-- scripts/patrol.lua
if not memory then memory = {} end

function onUpdate(npc)
    local id = npc:getID()
    local x = npc:getX()
    local y = npc:getY()

    if not memory[id] then
        memory[id] = {
            dir = 1,  -- 1 = avanti, -1 = indietro
            startX = x,
            endX = x + 5
        }
    end

    local data = memory[id]

    -- Movimento
    if data.dir == 1 then
        if x < data.endX then
            npc:moveBy(1, 0)
        else
            data.dir = -1
        end
    else
        if x > data.startX then
            npc:moveBy(-1, 0)
        else
            data.dir = 1
        end
    end
end
