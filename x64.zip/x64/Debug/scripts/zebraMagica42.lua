
return {
function OnInit(entity)
    print("[Lua] " .. entity.id .. " si è appena materializzato!")
end

function OnTalk(entity, player)
    print("[Lua] " .. player.name .. " sta parlando con " .. entity.id)
end

function OnClick(entity, player)
    print("[Lua] " .. player.name .. " ha cliccato su " .. entity.id)
end

function OnDead(entity)
    print("[Lua] " .. entity.id .. " è stato eliminato dal mondo.")
end
}