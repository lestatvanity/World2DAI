if not memory then memory = {} end

return {
    onUpdate = function(npc)
        print("[Lua] Aggiorno NPC: " .. npc:getID())

        local id = npc:getID()
        local x = npc:getX()
        local y = npc:getY()

        if not memory[id] then
            memory[id] = {
                dir = 1,
                startX = x,
                endX = x + 5
            }
        end

        local data = memory[id]

        if data.dir == 1 then
            if x < data.endX then
                npc:moveBy(1, 0)
            else
                data.dir = -1
            end
        else
            if x > data.startX then
                npc:moveBy(-1, 0)
            else
                data.dir = 1
            end
        end
    end
}
