return {
    onUpdate = function(id)
      print("[Lua] onUpdate chiamato per " .. id)
    end,
  
    onClick = function(id)
      print("[Lua] Click su " .. id)
    end
  }
  